---
title: OpenAPI Initiative gh-pages repository
description: HTML Spec. and extensible registry
---
# OpenAPI Initiative Registry

This site contains the OpenAPI Initiative Registry and content for the HTML versions of the OpenAPI Specification.

## Registry

* Proceed to [Registry](/registry/index.html)

## The Specification

* [Markdown source-of-truth](https://github.com/OAI/OpenAPI-Specification)
* [HTML Specification version](oas/v3.1.0.html)

# OpenAPI Initiative Registry

This site contains the OpenAPI Initiative Registry and content for the HTML versions of the OpenAPI Specification.

## Registry

* Proceed to [Registry](/registry/index.html)

## The Specification

* [Markdown source-of-truth](https://github.com/OAI/OpenAPI-Specification)
* [HTML Specification versions](https://openapis.org/specification)
